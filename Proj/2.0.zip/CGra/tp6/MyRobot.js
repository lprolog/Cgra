var step_size = 0.1;
var ang_rot = 45;
var degToRad = Math.PI / 180.0;
function MyRobot(scene) {
	CGFobject.call(this,scene);
	this.pos_x=0;
	this.pos_z=0;
	this.pos_ang=0;
	this.initBuffers();
};

MyRobot.prototype = Object.create(CGFobject.prototype);
MyRobot.prototype.constructor=MyRobot;

MyRobot.prototype.initBuffers = function () {
	this.vertices = [
            0.5, 0.3, 0,
            -0.5, 0.3, 0,
            0, 0.3, 2           
			];

	this.indices = [
            0, 1, 2,			
        ];

    this.normals = [
            0, 0, 1,
            0, 0, 1,
            0, 0, 1
    ];

    
	this.primitiveType=this.scene.gl.TRIANGLES;
	this.initGLBuffers();
};

MyRobot.prototype.roda_dir = function () 
{
	this.pos_ang-=ang_rot*degToRad;
};
MyRobot.prototype.anda_frente=function()
{
	this.pos_x+=step_size*Math.cos(this.pos_ang*degToRad);
	this.pos_z-=step_size*Math.sin(this.pos_ang*degToRad);
};
MyRobot.prototype.roda_esq=function()
{
	this.pos_ang+=ang_rot*degToRad;
}
MyRobot.prototype.anda_tras=function()
{
	this.pos_x-=step_size*(Math.cos(this.pos_ang*degToRad));
	this.pos_z+=step_size*(Math.sin(this.pos_ang*degToRad));
}
/*MyRobot.prototype.display = function()
 {
    this.scene.pushMatrix();
		this.scene.rotate(this.roda, 0, 1, 0);
		this.scene.translate(0,0,this.anda);
   		CGFobject.prototype.display.call(this);
    this.scene.popMatrix();
}*/;